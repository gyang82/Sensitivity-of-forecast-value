

function [a]=cal_example()


N0=1e6;
[t,y] = ode45(@bateman_ode,[0 1000],[N0 0 0 0 0]);
plot(t,y);

end







function [dN]=bateman_ode(t, N)
k = log(2)./[14/3600 64/3600 13*24 40 10000000000]; % in hours
dN(1) = -k(1)*N(1);
dN(2) = k(1)*N(1) - k(2)*N(2);
dN(3) = k(2)*N(2) - k(3)*N(3);
dN(4) = k(3)*N(3) - k(4)*N(4);
dN(5) = k(4)*N(4) - k(5)*N(5);
end


