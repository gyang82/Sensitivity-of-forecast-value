function [a]=cal_fig2()
close all
clear global
addpath('cbrewer');% color maps
addpath('export_fig\');%export figures
stg=[0.1:0.1:1];
cir=0.54*[0.1:0.1:1]';%capacity inflow ratio
capacity=[900:50:1150];
try     % get nice colours from colorbrewer
     % (https://uk.mathworks.com/matlabcentral/fileexchange/34087-cbrewer---colorbrewer-schemes-for-matlab)
     [cb] = cbrewer('qual', 'Set1', 9, 'pchip');
     colors=cb([1 3 4],:);
catch
     % if you don't have colorbrewer, accept these far more boring colours
     cb = [0.5 0.8 0.9; 1 1 0.7; 0.7 0.8 0.9; 0.8 0.5 0.4; 0.5 0.7 0.8; 1 0.8 0.5; 0.7 1 0.4; 1 0.7 1; 0.6 0.6 0.6; 0.7 0.5 0.7; 0.8 0.9 0.8; 1 1 0.4];
     colors=colormap(hsv(3));
end

data1=importdata('clN_capacity_lead.mat');

for i=1:length(capacity)
%     i=3
    if i~=3
        legend0    = [];
    else
        legend0    = {'Lead 1','Lead 2','Lead 3'};
    end
    title0=['Installed capacity: ',num2str(capacity(i)),' MW'];

y=data1.dF3{i};
ymin=min(min(y));
ymax=max(max(y));
ymin2=ymin-(ymax-ymin)*0.1;
% ymax2=-ymin2;
ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
% ymax2=ymax+(ymax-ymin)*0.07;
ymm=roundn(linspace(ymin2,ymax2,3),-1);
tick0=ymm;

y2 = cat(3,y-(ymax-ymin)/18,y,y+(ymax-ymin)/18);

[a]=fig_sub1(y2,colors,legend0,title0,tick0);

% % % save the figure to the file
dpi = 400;% set the dpi for the figure export
mag = dpi/get(0, 'ScreenPixelsPerInch'); 
% set(gca, 'Color', 'none');
export_fig(['clN_capacity_',num2str(capacity(i)),'.png'], sprintf('-m%g', mag));%export figure

end

a=0;

end


function [a]=fig_sub1(y,colors,legend0,title0,tick0)

opt_axes.Background = 'w';
% opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
opt_axes.Labels     = {'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};

opt_lines.LineWidth = 2;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = false;
% opt_lines.Legend    = {'Lead 1','Lead 2','Lead 3'};
opt_lines.Legend    = legend0;
opt_lines.Color     = colors;

opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.5;
opt_area.Color      = colors;
opt_area.title=title0;

opt_axes.Ticks=tick0;

figure()
polygonplot(y,opt_axes,opt_lines,opt_area);

a=0;
end