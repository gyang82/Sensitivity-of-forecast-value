function [a]=cal_fig2_2()
close all
clear global
addpath('cbrewer');% color maps
addpath('export_fig\');%export figures
stg=[0.1:0.1:1];
cir=0.54*[0.1:0.1:1]';%capacity inflow ratio
capacity=[900:50:1150];
try     % get nice colours from colorbrewer
     % (https://uk.mathworks.com/matlabcentral/fileexchange/34087-cbrewer---colorbrewer-schemes-for-matlab)
     [cb] = cbrewer('qual', 'Set1', 9, 'pchip');
     colors=cb([1 3 4],:);
catch
     % if you don't have colorbrewer, accept these far more boring colours
     cb = [0.5 0.8 0.9; 1 1 0.7; 0.7 0.8 0.9; 0.8 0.5 0.4; 0.5 0.7 0.8; 1 0.8 0.5; 0.7 1 0.4; 1 0.7 1; 0.6 0.6 0.6; 0.7 0.5 0.7; 0.8 0.9 0.8; 1 1 0.4];
     colors=colormap(hsv(3));
end

sumf=[5:11];
autf=[12:16];
nonf=[1:4,17:36];
aa=[-24*1000*365/1e8 -24*3600*365/1e8];% 1e8 kWh, 1e8 m3 power generation and water supply, respectively
waters=[60 65 70 75 80 85];
for kk=1:length(waters)
    datas=importdata(['results_capacity_lead_',num2str(waters(kk)),'.mat']);
    
    results=datas.results_capacity_lead; % results=[interflow qout v1 clN];
    
    for i=1:size(results,1) %capacity=[900:50:1150];
        for j=1:size(results,2) %lead=0, normal rules, lead=1,2,3, forecast rules
            result=results{i,j};
            clN=result(:,4);
            a=reshape(clN/1000,36,[]);
            a1(:,j)=mean(a,1)';
            a2(:,j)=mean(a,2);
            temp1(:,j)=[mean(reshape(a2(:,j),3,[]),1)'];
            
            qin=result(:,1);qin_y=mean(reshape(qin,36,[]),1)';
            v1s(:,j)=mean(reshape(result(:,3),36,[]),2);
            
        end
        clNm{i}(kk,:)=mean(a2);
        clNm_flood{i}(kk,:)=mean(a2([sumf,autf],:));clNm_nonf{i}(kk,:)=mean(a2([nonf],:));
        A1(1:2,:)=[mean(a2([sumf,autf],:));mean(a2([nonf],:))];
        A1(3,:)=mean(a2);
        
        clN_y{i}=a1;
        clN_m{i}=temp1;
        clN_10d{i}=a2;
        xxx1=clN_10d{i}([sumf,autf],:);xxx3=clN_10d{i}(nonf,:);
        yyy1=sum(xxx1)*1000*(365/36)*24/1e8;yyy3=sum(xxx3)*1000*(365/36)*24/1e8;
        yyy{i,kk}=[yyy1;yyy3]';
        
        
        
        dclN_y{i,kk}=[clN_y{i}(:,2)-clN_y{i}(:,1) clN_y{i}(:,3)-clN_y{i}(:,1) clN_y{i}(:,4)-clN_y{i}(:,1)];
        dclN_m{i,kk}=[clN_m{i}(:,2)-clN_m{i}(:,1) clN_m{i}(:,3)-clN_m{i}(:,1) clN_m{i}(:,4)-clN_m{i}(:,1)];
  
    end
    
    %% plot the figure with annal power generation difference
    x=dclN_y{1,kk}*(24*1000*365/1e9);aqin=qin_y;
%     title0=['Water supply: ', num2str(waters(kk)/10),' BCM'];
    title0=['Water supply: ', num2str(waters(kk)/10),' {\times}10^9 m^3'];
    [a]=fig_sub0(x,qin_y,colors,title0);
%     % % % save the figure to the file
%     dpi = 400;% set the dpi for the figure export
%     mag = dpi/get(0, 'ScreenPixelsPerInch'); 
%     set(gca, 'Color', 'none');
%     export_fig(['dclN_y_',num2str(waters(kk)),'.png'], sprintf('-m%g', mag));%export figure
%%    plot the figure with monthly power generation forecast value under different water supply level
    y=dclN_m{1,kk};
    ymin=min(min(y));
    ymax=max(max(y));
    ymin2=ymin-(ymax-ymin)*0.1;
    % ymax2=-ymin2;
    ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
    % ymax2=ymax+(ymax-ymin)*0.07;
    ymm=roundn(linspace(ymin2,ymax2,3),-1);
    tick0=ymm;
    
    if i~=6
        legend0    = [];
    else
        legend0    = {'Lead 1','Lead 2','Lead 3'};
    end
    title0=['Water supply: ', num2str(waters(kk)/10),' {\times}10^9 m^3'];
    temp0={'6.0' '6.5' '7.0' '7.5' '8.0' '8.5' };
    title0=['Water supply: ', temp0{kk},' {\times}10^9 m^3'];

    
    label0={'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};

    y2 = cat(3,y-(ymax-ymin)/18,y,y+(ymax-ymin)/18);

    [a]=fig_sub1(y2,colors,legend0,title0,tick0,label0);
    % % % save the figure to the file
    dpi = 800;% set the dpi for the figure export
    mag = dpi/get(0, 'ScreenPixelsPerInch'); 
    set(gca, 'Color', 'none');
    export_fig(['dclN_m_900_',num2str(waters(kk)),'.png'], sprintf('-m%g', mag));%export figure
end
%%    plot the figure with monthly power generation forecast value under different water supply level and installed capacity
for kk=1:length(waters)
    for i=1:size(results,1) %capacity=[900:50:1150];
        if i==1
            y=dclN_m{i,kk};
        else
            y=[y dclN_m{i,kk}];
        end
    end
    colors2=repmat(colors,size(results,1),1);
        ymin=min(min(y));
        ymax=max(max(y));
        ymin2=ymin-(ymax-ymin)*0.1;
        % ymax2=-ymin2;
        ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
        % ymax2=ymax+(ymax-ymin)*0.07;
        ymm=roundn(linspace(ymin2,ymax2,3),-1);
        tick0=ymm;

        if i~=3
            legend0    = [];
        else
            legend0    = {'Lead 1','Lead 2','Lead 3'};
        end
        title0=['Water supply: ', num2str(waters(kk)),' {\times}10^8 m^3'];
        label0={'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};

        y2 = cat(3,y-(ymax-ymin)/35,y,y+(ymax-ymin)/35);

%             [a]=fig_sub2(y2,colors2,legend0,title0,tick0,label0);
%             % % % save the figure to the file
%             dpi = 400;% set the dpi for the figure export
%             mag = dpi/get(0, 'ScreenPixelsPerInch'); 
%             set(gca, 'Color', 'none');
%             export_fig(['dclN_m_900-1150_',num2str(waters(kk)),'.png'], sprintf('-m%g', mag));%export figure
    
end

%%    plot the figure with monthly power generation forecast value under different water supply level and installed capacity 2
colors1=colormap(summer(6));
for kk=[1 6]
    
%     for j=1:size(results,2)-1 %lead=0, normal rules, lead=1,2,3, forecast rules
    for j=[1] %lead=0, normal rules, lead=1,2,3, forecast rules
        for i=1:size(results,1) %capacity=[900:50:1150];
            if i==1
                y=dclN_m{i,kk}(:,j);
            else
                y=[y dclN_m{i,kk}(:,j)];
            end
        end
%         colors2=repmat(colors,size(results,1),1);
        ymin=min(min(y));
        ymax=max(max(y));
        ymin2=ymin-(ymax-ymin)*0.1;
        % ymax2=-ymin2;
        ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
        % ymax2=ymax+(ymax-ymin)*0.07;
        ymm=roundn(linspace(ymin2,ymax2,3),-1);
        tick0=ymm;

        if i~=3
            legend0    = [];
        else
            legend0    = {'Lead 1','Lead 2','Lead 3'};
        end
%         title0=['Water supply: ', num2str(waters(kk)),' {\times}10^8 m^3','    Lead ',num2str(j)];
        label0={'6.0','6.5','7.0','7.5','8.0','8.5'};
        title0=['Water supply: ', label0{kk},' {\times}10^9 m^3'];
        label0={'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};

        y2 = cat(3,y-(ymax-ymin)/35,y,y+(ymax-ymin)/35);

            [a]=fig_sub2(y2,colors1,legend0,title0,tick0,label0);
            % % % save the figure to the file
            dpi = 800;% set the dpi for the figure export
            mag = dpi/get(0, 'ScreenPixelsPerInch'); 
            set(gca, 'Color', 'none');
            export_fig(['dclN_m_900-1150_',num2str(waters(kk)),'lead',num2str(j),'.png'], sprintf('-m%g', mag));%export figure
    
    end
        
end


%%   plot the figure with capacity and water supply level under different lead time 

for i=1:size(results,1) %capacity=[900:50:1150];
    for kk=1:length(waters)
        
    for j=1:size(results,2) %lead=0, normal rules, lead=1,2,3, forecast rules   
%         dclNm{i}(:,j)=clNm{i}(:,j+1)-clNm{i}(:,1);  
        if j==1
            dclNm{j}(kk,i)=clNm{i}(kk,1);
            dclNm_flood{j}(kk,i)=clNm_flood{i}(kk,1);
            dclNm_nonf{j}(kk,i)=clNm_nonf{i}(kk,1);
        else
            dclNm{j}(kk,i)=clNm{i}(kk,j)-clNm{i}(kk,1);
            dclNm_flood{j}(kk,i)=clNm_flood{i}(kk,j)-clNm_flood{i}(kk,1);
            dclNm_nonf{j}(kk,i)=clNm_nonf{i}(kk,j)-clNm_nonf{i}(kk,1);
        end
    end
    end
    
end

for j=1:size(results,2) %lead=0, normal rules, lead=1,2,3, forecast rules  
    
    y=dclNm{j};%annual power generation
%     y=dclNm_flood{j};%power generation in flood season
%     y=dclNm_nonf{j};%power generation in non-flood season
    
    ymin=min(min(y));
    ymax=max(max(y));
    ymin2=ymin-(ymax-ymin)*0.1;
    % ymax2=-ymin2;
    ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
    % ymax2=ymax+(ymax-ymin)*0.07;
    ymm=roundn(linspace(ymin2,ymax2,3),-1);
    tick0=ymm;
    
    if j~=5
        legend0    = [];
    else
        legend0    = {'900 MW','950 MW','1000 MW','1050 MW','1100 MW','1150 MW'};
    end
    if j==1
        title0=['Normal rules'];
    else
        title0=['Lead ',num2str(j-1)];
    end
    label0={'6.0','6.5','7.0','7.5','8.0','8.5'};

    y2 = cat(3,y-(ymax-ymin)/26,y,y+(ymax-ymin)/26);
    
    colors1=colormap(summer(6));
    [a]=fig_sub1(y2,colors1,legend0,title0,tick0,label0);
    title(title0,'Position', [0, -1.08, 0],'FontSize',13,'Color',[139 58 98]/255);
    
%         % % % save the figure to the file
    dpi = 800;% set the dpi for the figure export
    mag = dpi/get(0, 'ScreenPixelsPerInch'); 
    set(gca, 'Color', 'none');
    export_fig(['dclNm_capacity_lead',num2str(j-1),'.png'], sprintf('-m%g', mag));%export figure
end

%%





for i=1:6
   A1(:,i)=dclNm_nonf{1,i}(:,3);
end

end

function [a]=fig_sub0(dd,aqin,colors,title0)
figure()

width=1700;%���ȣ�������
height=width*0.25;%�߶�
left=20;%����Ļ���½�ˮƽ����
bottem=10;%����Ļ���½Ǵ�ֱ����
set(gcf,'position',[left,bottem,width,height])
gray=[0 255 255]/255;
red=[255 0 0]/255;
blue=[0 0 255]/255;
fontsize=17;

Fs=20;color_line=[0 191 255]/255;
% colormap(cool);% ����ͼ����ɫ
set(gca,'fontsize',20);
[AX,H1,H2]=plotyy([1:size(dd,1)]',dd,[1:length(aqin)]',aqin,@bar,@plot);
% set(AX(1),'XColor','k','YColor','b');
set(AX(2),'XColor','k','YColor',color_line);
for i=1:length(H1)
set(H1(i),'FaceColor',colors(i,:));
set(H1(i),'EdgeColor','none','BarWidth',1);
end
% ch = get(H1,'children');
% ch.FaceColor = colors(2,:);
% set(ch,'FaceVertexCData',[4;2;3;1;5;6]);%ʹ��Indexed��ʽָ��ÿ��bar����ɫ
% set(ch,'FaceVertexCData',[1;2;3]);%ʹ��Indexed��ʽָ��ÿ��bar����ɫ
% set(ch,'FaceColor',colors(2,:));

HH1=get(AX(1),'Ylabel');
set(HH1,'String','Increased P (10^9 kW\cdoth)','fontsize',Fs);
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Reservoir inflow (m^3/s)','fontsize',Fs);
set(HH2,'color',color_line);
set(H2,'LineStyle','-','color',color_line,'linewidth',2.0);

set(AX,'xlim',[0 32]) % ����x�᷶Χ
set(AX(1),'ylim',[-0.5 1]) % ����y�᷶Χ% ylim([-6 6]);
set(AX(1),'YTick',[linspace(-0.5,1,6)]);
set(AX(2),'ylim',[0 2500]) % ����y�᷶Χ% ylim([-6 6]);
set(AX(2),'YTick',[linspace(0,2500,6)]);
set(AX,'XTick',1:5:31);
set(AX,'XTickLabel',[1980:5:2010]);
set(AX(2),'XTickLabel',[])
hl=legend([H1 H2],{'Lead 1','Lead 2','Lead 3','Reservoir inflow'},'Location','Northeast','fontsize',18);
% set(hl,'Orientation','horizon')
% set(hl,'Box','off');
% xlabel('Years');
set(AX,'fontsize',20);

t2=text(13,0.9,title0,'color',[139 58 98]/255);
set(t2,'fontsize',20);
    
% t1=title(title0);


% % bar(dd);%��ά����ʽֱ��ͼ,Ĭ�ϵ�Ϊ'group'
% grid off;
% xlim([0 32]);
% % ylim([-6 6]);
% set(gca,'XTick',1:5:31);
% set(gca,'XTickLabel',[1980:5:2010])
% 
% hl=legend('Lead 1','Lead 2','Lead 3','Lead 4','Lead 5','Lead 6','Location','Northwest');
% set(hl,'Orientation','horizon')
a=0;
end

function [a]=fig_sub1(y,colors,legend0,title0,tick0,label0)

opt_axes.Background = 'w';
% opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
% opt_axes.Labels={'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};
opt_axes.Labels     = label0;
opt_lines.LineWidth = 2;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = false;
% opt_lines.Legend    = {'Lead 1','Lead 2','Lead 3'};
opt_lines.Legend    = legend0;
opt_lines.Color     = colors;

opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.5;
opt_area.Color      = colors;
opt_area.title=title0;

opt_axes.Ticks=tick0;

figure()
polygonplot(y,opt_axes,opt_lines,opt_area);

a=0;
end

function [a]=fig_sub2(y,colors,legend0,title0,tick0,label0)

opt_axes.Background = 'w';
% opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
% opt_axes.Labels={'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr',};
opt_axes.Labels     = label0;
opt_lines.LineWidth = 2;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = false;
% opt_lines.Legend    = {'Lead 1','Lead 2','Lead 3'};
opt_lines.Legend    = legend0;
opt_lines.Color     = colors;

opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.5;
opt_area.Color      = colors;
opt_area.title=title0;

opt_axes.Ticks=tick0;

figure()
polygonplot2(y,opt_axes,opt_lines,opt_area);

a=0;
end

