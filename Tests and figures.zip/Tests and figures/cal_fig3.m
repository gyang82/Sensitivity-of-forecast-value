function [a]=cal_fig3()
close all
clear global
addpath('cbrewer');% color maps
addpath('export_fig\');%export figures
stg=[0.1:0.1:1];
cir=0.54*[0.1:0.1:1]';%capacity inflow ratio
capacity=[900:50:1150];
name_rules={'Normal','Forecast-informed (lead 1)','Forecast-informed (lead 2)','Forecast-informed (lead 3)'};
try     % get nice colours from colorbrewer
     % (https://uk.mathworks.com/matlabcentral/fileexchange/34087-cbrewer---colorbrewer-schemes-for-matlab)
     [cb] = cbrewer('qual', 'Set1', 9, 'pchip');
%      colors=cb([1 3 4],:);
%      colors=colormap(hsv(length(capacity)));
     colors=colormap(cool(length(capacity)));
catch
     % if you don't have colorbrewer, accept these far more boring colours
     cb = [0.5 0.8 0.9; 1 1 0.7; 0.7 0.8 0.9; 0.8 0.5 0.4; 0.5 0.7 0.8; 1 0.8 0.5; 0.7 1 0.4; 1 0.7 1; 0.6 0.6 0.6; 0.7 0.5 0.7; 0.8 0.9 0.8; 1 1 0.4];
     colors=colormap(hsv(3));
end

data1=importdata('clN_capacity_lead.mat');
% y=data1{8};

opt_axes.Background = 'w';
% opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
opt_axes.Labels     = {'May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr'};

opt_lines.LineWidth = 2.5;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = false;
opt_lines.Legend    = {'900 MW','950 MW','1000 MW','1050 MW','1100 MW','1150 MW'};
opt_lines.Color     = colors;

opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.7;
opt_area.Color      = colors;

d_ex = [2 3; 1 0; 0.1 3; -1 7; -0.2 0.9];
data = cat(3,d_ex-0.5,d_ex,d_ex+0.7);

for i=1:length(name_rules)
    i=3
    if i~=3
        opt_lines.Legend    = [];
    else
        opt_lines.Legend    = {'900 MW','950 MW','1000 MW','1050 MW','1100 MW','1150 MW'};
    end
    opt_area.title=name_rules{i};
    figure(i)
    if i==1
        y=data1.F02';
    else
        y=data1.F_lead_stg{i-1}';
    end

mean(y)
ymin=min(min(y));
ymax=max(max(y));
ymin2=ymin-(ymax-ymin)*0.1;
% ymax2=-ymin2;
ymax2=max(-ymin2,ymax+(ymax-ymin)*0.05);
% ymax2=ymax+(ymax-ymin)*0.07;
ymm=roundn(linspace(ymin2,ymax2,3),-1);


y2 = cat(3,y-(ymax-ymin)/28,y,y+(ymax-ymin)/28);

opt_axes.Ticks=ymm;
polygonplot2(y,opt_axes,opt_lines,opt_area);

dpi = 400;% set the dpi for the figure export
mag = dpi/get(0, 'ScreenPixelsPerInch'); 
% set(gca, 'Color', 'none');
export_fig(['clN_rules_',num2str(i),'.png'], sprintf('-m%g', mag));%export figure

end


a=0;

opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.5;
opt_area.Color      = [128 193 219;
                       243 169 114]./255;
                   
opt_lines.LineWidth = 2;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = true;
opt_lines.Legend    = {'dataA','dataB'};
opt_lines.Color     = [ 52 148 186;
                      236 112  22]./255;
                  
opt_axes.Background = 'w';
opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
    
d_ex = [2 3; 1 0; 0.1 3; -1 7; -0.2 0.9];
data = cat(3,d_ex-0.5,d_ex,d_ex+0.7);

data1=importdata('clN_stg_lead.mat');



p1=polygonplot(data,opt_axes,opt_lines,opt_area);



a=0;

end