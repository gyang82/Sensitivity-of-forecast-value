function [a]=calop()

% ���㲻ͬ��������ͬĿ����ȹ�����ˮ��ƽ��������ˮλ
close all
% str={'1 input P.mat';'1 input 2 P.mat';'2 inputs P.mat';'3 inputs P.mat'};
% str={'1 input W.mat';'1 input 2 W.mat';'2 inputs W.mat';'3 inputs W.mat'};
% str={'200100W.mat';'210130W.mat';'128139W.mat';'124139W.mat'};
% str={'200100P.mat';'210130P.mat';'128139P.mat';'124139P.mat'};

% str={'normalP.mat';'powerP.mat';'waterP.mat'};
str={'generalP.mat';'forecastP2.mat';'��ˮ0.0.mat'};
% str={'changgui.mat'};
% str={'000000 W.mat';'128139 W.mat';'231039 W.mat'};
% str={'��ˮ1.0.mat';'231039 P.mat'};
% str={'000000 P.mat';'128139 P.mat';'231039 P.mat'};
sumf=[5:11];
autf=[12:16];
nonf=[1:4,17:36];

% load('1 input P.mat');
% load('1 input 2 P.mat');
% load('2 inputs P.mat');
% load('3 inputs P.mat');

% load('������ ����-�������ݼ� 1980-2010.mat');
for mmm=1:31
for ii=1:length(str)

    
load(str{ii});
m=36;n=max(size(clN))/m;

QIN=reshape(qin,m,n);
QINm=mean(QIN)';
[temp,tempn]=sort(QINm,'descend');
Ns=round(0.1*n);

Nwet=tempn(1:Ns);Ndry=tempn(end-Ns+1:end);

% CLN=(clN)/1000;
% CLN=reshape(CLN,m,n);

if size(clN,2)>size(clN,1)
    clN=clN';
end

% CLN=(clN0+clN)/1000;
% CLN=reshape(CLN,m,n);


% CLN=reshape(qmin,m,n);
% for Ankang reservoir 
% CLN=reshape(h10,m,n);
% if ii==3
%     % for Ankang reservoir 
%     CLN=reshape(h11,m,n);
%     % for Danjiangkou reservoir
% %     CLN=reshape(h1,m,n);
% end
% for Danjiangkou reservoir
CLN=reshape(h1,m,n);

aa(:,1)=mean(CLN')';
aa(:,2)=min(CLN')';
aa(:,3)=max(CLN')';

% �������ƽ������͹�ˮ����
aaa(:,ii)=mean(CLN')';
aaaWet(:,ii)=mean(CLN(:,Nwet)',1)';
aaaDry(:,ii)=mean(CLN(:,Ndry)',1)';

ddd=CLN(:,mmm);
eee(:,ii)=ddd;
end
% figure(mmm);
% plot(eee);
% hold on
% ���㷢����
xxx1=aaa([sumf,autf],:);
yyy1=sum(xxx1)*1000*(365/36)*24/1e8;
% xxx2=aaa(autf,:);
% yyy2=sum(xxx2)*1000*(365/36)*24/1e8;
xxx3=aaa(nonf,:);
yyy3=sum(xxx3)*1000*(365/36)*24/1e8;

% ���㹩ˮ��
% xxx1=aaa([sumf,autf],:);
% yyy1=sum(xxx1)*3600*(365/36)*24/1e8;
% % % % % xxx2=aaa(autf,:);
% % % % % yyy2=sum(xxx2)*3600*10*24/1e8;
% xxx3=aaa(nonf,:);
% yyy3=sum(xxx3)*3600*(365/36)*24/1e8;

yyy=[yyy1;yyy3]';

% CLN=[];
end

end